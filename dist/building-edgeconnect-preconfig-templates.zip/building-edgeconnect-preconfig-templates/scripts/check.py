#!/usr/bin/env python3
"""Stage 8 checks for one site type folder (output of translate.py or generate.py), plus optional /validate.

1 headers match   2 renders and parses   4 variables flow through (multicast on has an RP; no value /validate is known to reject)   5 mutation (one column at a time)
8 example row reproduces reference.yaml   10 validation recorded (with --validate)   7 no secrets in the example row
11 ledger matches the YAML (translate.py folders: every mapped line written, every written section ledgered)
Reads <site>.jinja2, <site>.csv, example.csv, columns.json, reference.yaml. Writes checks.json and rendered/.
Extra rows (--rows CSV) are rendered and checked the same way.
"""
import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import changed_paths, load_yaml, normalize_serial, parse_yaml, resolve_output_filename, write_json  # noqa: E402
from render import flow_through, headers, read_rows, render_row  # noqa: E402


def mutate(value: str, meta: Dict[str, Any]) -> Optional[str]:
    kind = meta["type"]
    if kind == "bool":
        return "false" if value.lower() == "true" else "true"
    if kind == "int":
        return str(int(value) + 1)
    if kind == "float":
        return str(float(value) + 1)
    if kind == "comma-list":
        head, _, last = value.rpartition(",")
        return (head + "," if head else "") + last + "-m"
    return value + "-m"


def no_rp(doc: Any) -> List[str]:
    """Orchestrator /validate refuses multicast enable true without rpAddresses; say so offline."""
    entries = doc.get("multicast") if isinstance(doc, dict) else None
    return ["multicast[{}] (segment {}): enable true without rpAddresses; Orchestrator /validate rejects it, set the RP".format(i, e.get("segment"))
            for i, e in enumerate(entries if isinstance(entries, list) else []) if isinstance(e, dict) and str(e.get("enable")).lower() == "true" and e.get("rpAddresses") in (None, "", [])]


VRRP_KEY_MAX = 8  # Orchestrator /validate: "VRRP - authenticationString is maximum 8 characters" (full-coverage lab)


def dummy_secret(path: str) -> str:
    """The stand-in for an empty secret cell in a /validate run: one /validate accepts for that field."""
    return "TestOnl1" if path.endswith("authenticationString") else "Test-Only-Secret-1"


def validate_rejects(doc: Any) -> List[Any]:
    """(section, reason) for each value the appliance holds that Orchestrator /validate rejects (full-coverage lab, Pass 1, 2026-10-31):
    named offline, never changed."""
    if not isinstance(doc, dict):
        return []
    out = []
    ospf = [("ospfSystemConfig", doc.get("ospfSystemConfig"))] + [("segmentOspfConfig", x) for x in (doc.get("segmentOspfConfig") or [])]
    for section, o in (x for x in ospf if isinstance(x[1], dict)):
        for a in (x for x in (o.get("areas") or []) if isinstance(x, dict)):
            if str(a.get("areaType")) not in ("0", "1"):
                out.append((section, "OSPF area {} (segment {}): areaType {} is not 0 (standard) or 1 (NSSA); Orchestrator /validate rejects it, ECOS 9.6.2.1 has it as a stub area".format(
                    a.get("areaId"), o.get("segment", "Default"), a.get("areaType"))))
    info = doc.get("deploymentInfo") if isinstance(doc.get("deploymentInfo"), dict) else {}
    for d in (x for x in (info.get("dhcpInfo") or []) if isinstance(x, dict)):
        if d.get("enableOptions82") is True and not any(v is True for k, v in d.items() if k.startswith("option82SubOptions")):
            out.append(("deploymentInfo", "DHCP relay on {}: option 82 is on with no sub-option; Orchestrator /validate needs at least one option82SubOptions true".format(d.get("dhcpInterfaceName"))))
    seen: Dict[Any, int] = {}
    for i in (x for x in (info.get("deploymentInterfaces") or []) if isinstance(x, dict) and x.get("interfaceType") == "wan"):
        key = (i.get("interfaceName"), i.get("interfaceLabel"))
        seen[key] = seen.get(key, 0) + 1
        if seen[key] == 2:
            out.append(("deploymentInfo", "WAN {}: two entries (dual stack) with the same label {}; Orchestrator /validate rejects it, the IPv6 entry needs its own label".format(*key)))
    vrrp = doc.get("vrrp") if isinstance(doc.get("vrrp"), dict) else {}
    for v in (x for x in (vrrp.get("vrrpEntries") or []) if isinstance(x, dict)):
        key = v.get("authenticationString")
        if isinstance(key, str) and not key.startswith("<SECRET:") and len(key) > VRRP_KEY_MAX:  # the length only, never the key
            out.append(("vrrp", "VRRP group {} on {}: the authentication key is {} characters; Orchestrator /validate allows at most {} (full-coverage lab)".format(
                v.get("groupId"), v.get("interfaceName"), len(key), VRRP_KEY_MAX)))
    return out


def run(site_dir: Path, site: str, extra_rows: Optional[Path], validate: Optional[str], substitute: bool = False) -> Dict[str, Any]:
    meta = json.loads((site_dir / "columns.json").read_text())
    columns = meta["columns"]
    site = meta.get("site_type", site)
    template = site_dir / (site + ".jinja2")
    result: Dict[str, Any] = {"site_type": site, "checks": {}}

    def record(name: str, ok: bool, detail: Any = "") -> None:
        result["checks"][name] = {"ok": ok, "detail": detail}

    wanted = list(columns) + [c for c in meta["runner_columns"]]
    csv_header = (site_dir / (site + ".csv")).read_text().splitlines()[0].split(",")
    found = headers(template.read_text())
    record("1 headers match", set(found) == set(columns) and set(csv_header) == set(wanted) | ({"hostname"} - set(wanted)), {"template": len(found), "csv": len(csv_header)})

    rows = read_rows(site_dir / "example.csv") + (read_rows(extra_rows) if extra_rows else [])
    rendered_dir = site_dir / "rendered"
    rendered_dir.mkdir(exist_ok=True)
    val_client, inv, subst_notes = None, None, []
    if validate:
        from validate import validate_text, validator
        val_client = validator(validate)
        if substitute:
            from synth import dump, inventory, substitute as swap
            inv = inventory(val_client)

    docs, files, problems, verdicts = [], [], [], []
    seen_files: Dict[str, int] = {}
    for idx, row in enumerate(rows, 1):
        row_problems: List[str] = []
        pcfg_name, fname = ("row_{}".format(idx), "")
        try:
            pcfg_name, fname = resolve_output_filename(row, idx)
            if fname in seen_files:
                row_problems.append("duplicate output filename {!r} in rows {} and {}".format(fname, seen_files[fname], idx))
            else:
                seen_files[fname] = idx
            norm_serial = normalize_serial(row.get("serial_number")) if row.get("serial_number") else None
            text = render_row(template, row)
            doc = parse_yaml(text)
            row_problems.extend(flow_through(doc, columns, row))
            row_problems.extend(no_rp(doc) + [why for _, why in validate_rejects(doc)])
        except Exception as error:
            row_problems.append(str(error)[:150])
            text, doc, norm_serial = "", None, None

        if not row_problems and val_client is not None:
            row_for_validation = dict(row)
            for n, c in columns.items():
                if c["secret"] and c["had_value"] and not row_for_validation[n]:
                    row_for_validation[n] = dummy_secret(c["path"])
            val_text = render_row(template, row_for_validation)
            if inv is not None:
                val_text = dump(swap(parse_yaml(val_text), inv, subst_notes))
            verdict = validate_text(val_client, val_text, norm_serial)
            verdicts.append({"file": fname, "accepted": verdict["accepted"], "error": verdict["error"]})
            if not verdict["accepted"]:
                row_problems.append("Orchestrator /validate rejected row: {}".format(verdict["error"]))

        if row_problems:
            problems.extend("{}: {}".format(pcfg_name, p) for p in row_problems)
            if fname and (rendered_dir / fname).exists() and seen_files.get(fname) == idx:
                (rendered_dir / fname).unlink()
            continue

        path = rendered_dir / fname
        path.write_text(text, encoding="utf-8")
        docs.append((row, doc))
        files.append(path)

    record("2 renders and parses", len(docs) == len(rows), "{} valid of {} rows".format(len(docs), len(rows)))
    record("4 variables flow through", not problems, problems[:5])

    if docs:
        row0, doc0 = docs[0]
        bad = []
        for name, col in columns.items():
            changed = mutate(row0[name], col) if row0[name] != "" or col["type"] in ("string", "comma-list") else None
            if changed is None:
                continue
            try:
                doc = parse_yaml(render_row(template, dict(row0, **{name: changed})))
            except Exception as error:
                bad.append("{}: {}".format(name, str(error)[:80]))
                continue
            own = [col["path"]] + col.get("also_at", [])  # one value the source repeats at several paths is one column
            extra = [p for p in changed_paths(doc0, doc) if not any(p == o or p.startswith(o + "[") for o in own)]
            if extra:
                bad.append("{} also changed {}".format(name, extra[:2]))
        record("5 mutation: one column changes only its field", not bad, bad[:5])

        reference = load_yaml(site_dir / "reference.yaml") if (site_dir / "reference.yaml").exists() else None
        if reference is not None:
            diffs = [p for p in changed_paths(reference, doc0)]
            secret_paths = {c["path"] for c in columns.values() if c["secret"]}
            record("8 example row reproduces reference", set(diffs) <= secret_paths, [d for d in diffs if d not in secret_paths][:8])
    ledger_file, ref_file = site_dir / "ledger.json", site_dir / "reference.yaml"
    if ledger_file.exists() and ref_file.exists():  # a translate.py folder: the ledger and the YAML must tell the same story
        from translate import unledgered_sections, unwritten_mapped
        entries, reference = json.loads(ledger_file.read_text())["entries"], load_yaml(ref_file)
        mismatch = ["ledger says mapped, YAML lacks: " + e["target"] for e in unwritten_mapped(entries, reference)] + \
                   ["YAML writes, no ledger line: " + s for s in unledgered_sections(entries, reference)]
        record("11 ledger matches the YAML", not mismatch, mismatch[:8])
    leaks = [n for n, c in columns.items() if c["secret"] and rows[0].get(n)]
    record("7 example row holds no secret values", not leaks, leaks)

    if validate:
        record("10 validation recorded", bool(verdicts) and all(v["accepted"] for v in verdicts), verdicts)
        result["validator"] = {"orchestrator": validate, "write_requests": val_client.write_requests, "substitution_notes": sorted(set(subst_notes))}
    result["ok"] = all(c["ok"] for c in result["checks"].values())
    write_json(site_dir / "checks.json", result)
    return result


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("site_dir", type=Path)
    parser.add_argument("--rows", type=Path, help="extra CSV rows to render and check")
    parser.add_argument("--validate", metavar="ORCHESTRATOR", help="validator nickname (e.g. lab)")
    parser.add_argument("--substitute", action="store_true", help="replace object names by names that exist on the validator (for configurations taken from another Orchestrator)")
    args = parser.parse_args(argv)
    from validate import Stop
    try:
        result = run(args.site_dir, args.site_dir.name, args.rows, args.validate, args.substitute)
    except Stop as stop:
        print("STOPPED: {}".format(stop), file=sys.stderr)
        return 2
    for name, c in result["checks"].items():
        print("{} {}{}".format("PASS" if c["ok"] else "FAIL", name, "" if c["ok"] else "  " + json.dumps(c["detail"])[:400]))
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
